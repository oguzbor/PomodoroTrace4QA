
# PomodoroTrace4QA

Java + Selenium testleri yazarken her test senaryosu için otomatik Pomodoro loglayan sistem.

## Kullanım
Her @Test metoduna PomodoroLogger.log(...) satırını ekleyin.

## Log Formatı
log-output.json dosyasına JSON formatında log kayıtları atılır.
